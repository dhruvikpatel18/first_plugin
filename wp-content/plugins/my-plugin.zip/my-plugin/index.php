<?php
/** silence is golden */
?>